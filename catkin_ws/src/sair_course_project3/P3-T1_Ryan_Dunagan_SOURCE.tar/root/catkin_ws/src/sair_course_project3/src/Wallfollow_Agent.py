#!/usr/bin/env python3

import rospy
import math

# For reading command line inputs
from sys import argv
import sys

# For creating data structures for q-learning
import numpy as np

# For Euler-quaternion transformation
# from scipy.spatial.transform import Rotation
from tf.transformations import euler_from_quaternion, quaternion_from_euler

# For manual debug input
if sys.platform == 'win32':
    import msvcrt
else:
    import termios
    import tty
from select import select

# # Used in Type Annotation
# from typing import Tuple

# Used in list copying
from copy import deepcopy

# Bring in geometry structures necessary to give movement commands
from geometry_msgs.msg import Pose, Point, Quaternion, Twist

# # Import tf to get the position of the robot
# import tf

# Used to get info from the Laser sensor
from sensor_msgs.msg import LaserScan

# Used to set/get Gazebo Model State
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import GetModelState, SetModelState

# Use this to reset the simulation
from std_srvs.srv import Empty


"""
Possible states:
    State consists of Front, RightFront, Right, and Left
    Right and Front can be one of:
        C - Close
        M - Medium
        F - Far
    RightFront and Left can only be one of:
        C - Close
        F - Far
    State space (3^2 * 2^1 * 2^1 = 36):
        ["C/M/F", "C/F", "C/M/F", "C/F"]
"""

"""
Possible actions:
    Possible directions:
        S - Straight
        R - Right
        L - Left
    Possible distances:
        S - Short
        L - Long
    Action space (3^1 * 2^1 = 6):
        SS - Straight short
        SL - Straight long
        RS - Right short
        RL - Right long
        LS - Left short
        LL - Left long
"""

class WallfollowAgent:
    """
    A class that:
        Utilizes Reinforcement Q-Learning to follow a right-hand wall.

    Member Variables
    ----------------
    @var: name : type
        Description
    """
    # Default the init parameters to the values of the /map OccupancyGrid
    def __init__(self):
        self.front_states = 3 # Front = C/M/F
        self.frontright_states = 2 # Front = C/F
        self.right_states = 3 # Right = C/M/F
        self.left_states = 2 # Left = C/F
        
        self.laser_data = None # Stores data from the Laser scanner of type LaserScan

        is_training = True # Default to training mode
        is_demo = False # Allow to set demo mode
        self.manual_control = False # Is the robot being manually controlled?

        # Perform object initialization
        self.init_node()
        self.init_publishers()
        self.init_subscriber()
        self.init_gazebo()

        # Interpret command line inputs to figure out if we want to run in training mode or demo mode
        if len(argv) == 2: # Exactly one cli argument
            try:
                # Determine mode based on arguments
                is_training = (argv[1].casefold() == "training") or (argv[1].casefold() == "manual")
                is_demo = (argv[1].casefold() == "demo")
                self.manual_control = (argv[1].casefold() == "manual")

                # Output mode selection
                rospy.loginfo(f"Training mode? {is_training}")
                rospy.loginfo(f"Demo mode? {is_demo}")
                rospy.loginfo(f"Manual control? {self.manual_control}")
            except Exception as exc:
                rospy.logwarn(f"Invalid command line arguments given, defaulting to training mode.")
        elif len(argv) != 1: # Wrong amount of cli arguments
            rospy.logwarn(f"Incorrect amount of command line arguments given, defaulting to training mode.")
        else: # No cli arguments
            rospy.loginfo(f"No command line arguments given, defaulting to training mode.")

        # If we are running in training mode
        if is_training:
            rospy.loginfo("Initializing Wallfollow Agent in Training mode...")
            # Initialize learning
            self.initialize_qlearning()

            # Begin the task of autonomous wallfollow navigation
            self.wallfollow_navigate_training()
        elif is_demo:
            rospy.loginfo("Initializing Wallfollow Agent in Demo mode...")
            rospy.loginfo("Demo mode not yet implemented!")

    #region Functions / Object Initialization

    def init_node(self)->None:
        """ Initializes a rospy node so we can publish and subscribe over ROS. """
        rospy.init_node('wallfollow_agent_py')

    def init_publishers(self)->None:
        """ Initializes any publishers we'll need in this agent. """
        # Initialize the publisher that publishes movement commands to the robot
        self.movement_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

    def init_subscriber(self)->None:
        """ Initializes any subscribers we'll need in this agent. """
        # Initialize the subscriber that consumes the Laser Sensor info
        self.laser_sub = rospy.Subscriber('/scan', LaserScan, self.set_laser_data)

    #endregion

    #region Q-Learning

    def initialize_qlearning(self)->None:
        """
        Initializes all data and data structures necessary for the q-learning process.
        """
        # Init function values
        self.epsilon = 0.9 # Percent of time to take best action
        self.discount_factor = 0.9 # Discount factor for future rewards
        self.learning_rate = 0.9 # Rate at which the AI should learn

        # Init actions
            #0 = SS - Straight short
            #1 = SL - Straight long
            #2 = RS - Right short
            #3 = RL - Right long
            #4 = LS - Left short
            #5 = LL - Left long
        # There are 6 total actions the bot can take
        self.actions = ["SS", "SL", "RS", "RL", "LS", "LL"]

        # Init Q Table
        # First 4 dimensions represent the state, 5th dimension represents the action
        self.q_table = np.zeros((self.front_states, self.frontright_states, self.right_states, self.left_states, len(self.actions)))

        # PART 1 STUFF START

        # Set q table values manually for straight-wall following
        self.manual_q_table_straight_wall()

        # PART 1 STUFF END

        # Init the current state
        self.current_state = [0, 0, 0, 0] # Default current state to all closest values 
        self.last_state = [0, 0, 0, 0] # Default last state to all closest values 

    def manual_q_table_straight_wall(self):
        """
        Manually define a Q-Table policy for following a straight wall.
        self.q_table[Front, Frontright, Right, Left]
        Front:      0=C,    1=M,    2=F
        Frontright: 0=C,    1=F
        Right:      0=C,    1=M,    2=F
        Left:       0=C,    1=F
        Actions:
            0 = SS - Straight short
            1 = SL - Straight long
            2 = RS - Right short
            3 = RL - Right long
            4 = LS - Left short
            5 = LL - Left long
        """
        # With manually defined values, we want to listen to our q-table all of the time
        self.epsilon = 1.0 # Percent of time to take best action
        
        # For all front values
        for front in range(3):
            # For all left values
            for left in range(2):
                self.q_table[front, 0, 0, left, 0] = 1.0 # Straight Short if near right wall with good angle
                self.q_table[front, 0, 1, left, 0] = 1.0 # Straight Short if moving towards right wall
                # self.q_table[front, 0, 1, left, 4] = 1.0 # Left Short if moving towards right wall
                self.q_table[front, 0, 2, left, 1] = 1.0 # Straight Long if near right wall but moving away
                # self.q_table[front, 0, 2, left, 5] = 1.0 # Left Long if near right wall but moving away
                self.q_table[front, 1, 0, left, 2] = 1.0 # Right Short if near right wall and moving away
                self.q_table[front, 1, 1, left, 1] = 1.0 # Straight long if near right wall with good angle
                self.q_table[front, 1, 2, left, 1] = 1.0 # Straight Long if away from wall (move to wall)

    #endregion

    #region Wallfollow Navigation

    def set_laser_data(self, data:LaserScan)->None:
        """
        Callback function that receives the LaserData from self.laser_sub.
        """
        # Receive the LaserData
        self.laser_data = data

        # # Print out occupancy grid info
        # if self.laser_data != None:
        #     rospy.loginfo("Obtained LaserScan!")

    def wallfollow_navigate_training(self, num_episodes:int = 1000)->None:
        """
        Run num_episodes training episodes.
        """
        # Make sure not to do anything until initial laser data is retrieved
        while self.laser_data is None and not rospy.is_shutdown():
            rospy.loginfo("Waiting to receive initial laser scan data.")
            rospy.Rate(2).sleep()
        if not self.laser_data is None:
            rospy.loginfo("Initial laser scan data retrieved!")

        # Handle rospy shutdown
        if rospy.is_shutdown():
            rospy.loginfo("rospy has shut down!")
            return None

        # For num_episodes amount of episodes
        for i in range(1, num_episodes+1):
            rospy.loginfo("------------------------------------")
            rospy.loginfo(f"Beginning episode {i}!")
            # Choose a valid starting position, and get the state
            self.initialize_wallfollow()
            self.current_state = self.get_current_state()

            # Make sure we're in a nonterminal position
            has_collided = self.check_for_collision()
            while has_collided and not rospy.is_shutdown():
                # Wait until position resetting has occurred
                rospy.Rate(5).sleep()
                has_collided = self.check_for_collision()
            
            # Handle rospy shutdown
            if rospy.is_shutdown():
                rospy.loginfo("rospy has shut down!")
                return None

            # While we haven't collided with an obstacle
            while not has_collided and not rospy.is_shutdown():
                # Choose an action given the current state using epsilon greedy
                action_index = self.get_next_action()

                # Manual input for testing
                if self.manual_control:
                    manual_input = self.manual_input()
                    action_index = manual_input

                # Perform the chosen action, update the current state.
                if not action_index == -1:
                    self.perform_action(self.actions[action_index]) # Action selected via epsilon greedy
                else:
                    self.perform_action("XX") # Control signal to stop moving

                # Store the old state and update the current state
                self.last_state = deepcopy(self.current_state)
                self.current_state = self.get_current_state()

                # Check to see if new state is terminal (and start new episode if so)
                has_collided = self.check_for_collision()

                # PART 2 STUFF START

                # # Receive reward for entering state, calculate temporal difference
                # reward = 0 #TODO: Set up reward structure
                # old_q_value = self.q_table[self.last_state[0], self.last_state[1], self.last_state[2], self.last_state[3], action_index]
                # temporal_difference = reward + (self.discount_factor * np.max(self.q_table[self.current_state[0], self.current_state[1], self.current_state[2], self.current_state[3]])) - old_q_value

                # # Update Q-value for previous state action pair
                # new_q_value = old_q_value + (self.learning_rate * temporal_difference)
                # self.q_table[self.last_state[0], self.last_state[1], self.last_state[2], self.last_state[3], action_index] = new_q_value

                # PART 2 STUFF END

                # Delay until next action
                rospy.Rate(2).sleep()
        
            # Handle rospy shutdown
            if rospy.is_shutdown():
                rospy.loginfo("rospy has shut down!")
                return None

            # Handle collision
            if has_collided:
                self.perform_action("XX") # Control signal to stop moving
                rospy.loginfo("Agent has collided with an obstacle! Ending episode.")

        rospy.loginfo("------------------------------------")
        rospy.loginfo(f"Completed {num_episodes} episode(s) of training!")

    def initialize_wallfollow(self)->None:
        """ Reset the simulation and set the robot's starting position. """
        # Reset the Gazebo environment
        rospy.loginfo("Resetting Gazebo simulation!")
        self.gz_reset_simulation()

        # Move robot to given starting location (pause physics when moving)
        self.gz_pause_physics()
        x_pos, y_pos, z_rot = self.get_starting_location()
        self.gz_set_model_state(x_pos, y_pos, z_rot)
        rospy.loginfo(f"Initializing robot to position ({round(x_pos, 2)}, {round(y_pos, 2)}) with z rotation {round(z_rot, 2)}!")
        self.gz_unpause_physics()

    def get_starting_location(self)->tuple:
        """
        Returns a random starting location from a list of set locations of the form (x_pos, y_pos, z_rot).
        For rotation, 0 = up, 90 = left, 180 = down, 270 = right
        """
        # List of starting locations of the form (x_pos, y_pos, z_rot)
        starting_locations = np.array([
            # (0.75, 2.0, 180.0), # Test straight wall
            # (0.85, 0.75, 135.0), # Test diagonal into straight wall
            (2.0, 0.0, 90.0), # Top Center, approaching U-turn
            (1.0, -2.0, 0.0), # Center Right, approaching corner
            (0.0, 2.0, 180.0), # Center Left, approaching corner
            (-2.0, -2.0, 0.0), # Bottom Right, approaching I turn
            (-2.0, 2.0, 270.0), # Bottom Left, approaching I turn
            ])
        return starting_locations[np.random.randint(0, len(starting_locations))]

    def check_for_collision(self, collision_range:float = 0.2)->bool:
        """
        Examines the LaserData and determines if we're close enough to an obstacle in any direction that we have crashed.

        Returns
        -------
        bool : True if we have crashed, and false otherwise.
        """
        for i in range(len(self.laser_data.ranges)):
            if self.laser_data.ranges[i] <= collision_range:
                return True
        return False

    def get_current_state(self)->list:
        """
        Takes measurements from the Laser sensor and determines the current state.
        """
        # print(f"Front: {self.laser_data.ranges[0]}, {self.laser_data.intensities[0]}")
        # print(f"Left: {self.laser_data.ranges[89]}, {self.laser_data.intensities[89]}")
        # print(f"Back: {self.laser_data.ranges[179]}, {self.laser_data.intensities[179]}")
        # print(f"Right: {self.laser_data.ranges[269]}, {self.laser_data.intensities[269]}")
        
        # Calculate the ranges
        range_front = 0.0
        range_frontright = 0.0
        range_right = 0.0
        range_left = 0.0

        # Take 5 measurements on each side (11 total) and sum them
        for i in range (-5,6):
            range_front += self.laser_data.ranges[0 + i]
            range_frontright += self.laser_data.ranges[299 + i]
            range_right += self.laser_data.ranges[269 + i]
            range_left += self.laser_data.ranges[89 + i]
        # Calculate range averages
        range_front /= 11.0
        range_frontright /= 11.0
        range_right /= 11.0
        range_left /= 11.0

        # Categorize the ranges
        cat_front = self.categorize_front(range_front)
        cat_frontright = self.categorize_frontright(range_frontright)
        cat_right = self.categorize_right(range_right)
        cat_left = self.categorize_left(range_left)

        # Return the categorizations as the state
        return [cat_front, cat_frontright, cat_right, cat_left]

    #region Directional Distance Categorizations

    def categorize_front(self, dist:float)->int:
        """
        Given a distance for the front sensor, categorize it.
        0=C, 1=M, 2=F
        """
        # Handle inf case
        if dist == float("inf"):
            return 2

        # Perform categorization
        if dist < 0.24:
            return 0
        elif dist < 0.48:
            return 1
        else:
            return 2

    def categorize_frontright(self, dist:float)->str:
        """
        Given a distance for the frontright sensor, categorize it.
        0=C, 1=F
        """
        # Handle inf case
        if dist == float("inf"):
            return 1

        # Perform categorization
        if dist <= 0.32:
            return 0
        else:
            return 1

    def categorize_right(self, dist:float)->str:
        """
        Given a distance for the right sensor, categorize it.
        0=C, 1=M, 2=F
        """
        # Handle inf case
        if dist == float("inf"):
            return 2

        # Perform categorization
        if dist < 0.24:
            return 0
        elif dist <= 0.32:
            return 1
        else:
            return 2

    def categorize_left(self, dist:float)->str:
        """
        Given a distance for the left sensor, categorize it.
        0=C, 1=F
        """
        # Handle inf case
        if dist == float("inf"):
            return 1

        # Perform categorization
        if dist <= 0.2:
            return 0
        else:
            return 1

    #endregion

    #region Manual Input

    def manual_input(self)->int:
        """
        Checks for keyboard inputs and returns action indices or -1 if no input.
        """
        # Get a key press
        key = self.get_key()
        if key == 's':  # if key 's' is pressed 
            # rospy.loginfo('You Pressed the S Key!')
            return 0
        elif key == 'w':  # if key 'w' is pressed 
            # rospy.loginfo('You Pressed the W Key!')
            return 1
        elif key == 'd':  # if key 'd' is pressed 
            # rospy.loginfo('You Pressed the D Key!')
            return 2
        elif key == 'e':  # if key 'e' is pressed 
            # rospy.loginfo('You Pressed the E Key!')
            return 3
        elif key == 'a':  # if key 'a' is pressed 
            # rospy.loginfo('You Pressed the A Key!')
            return 4
        elif key == 'q':  # if key 'q' is pressed 
            # rospy.loginfo('You Pressed the Q Key!')
            return 5
        
        # No keys were pressed
        return -1

    def get_key(self)->str:
        settings = self.saveTerminalSettings()
        timeout = rospy.get_param("~key_timeout", 0.5)

        if sys.platform == 'win32':
            # getwch() returns a string on Windows
            key = msvcrt.getwch()
        else:
            tty.setraw(sys.stdin.fileno())
            # sys.stdin.read() returns a string on Linux
            rlist, _, _ = select([sys.stdin], [], [], timeout)
            if rlist:
                key = sys.stdin.read(1)
            else:
                key = ''
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return key

    def saveTerminalSettings(self):
        if sys.platform == 'win32':
            return None
        return termios.tcgetattr(sys.stdin)

    #endregion

    def perform_action(self, action:str)->None:
        """
        Perform the given action.
        """
        # # Make sure the action exists
        # if action not in self.actions:
        #     rospy.logerr(f"Invalid action {action} given! Cannot perform action.")
        #     return None

        cs = self.current_state
        rospy.loginfo(f"PA: {cs[0]}, {cs[1]}, {cs[2]}, {cs[3]}, {action}")
        # rospy.loginfo(f"Performing action: {action}")

        # Get the robot's orientation
        pos, ori = self.gz_get_model_state()
        # Get the Euler z rotation from the quaternion ori
        rot = euler_from_quaternion([ori.w,ori.x,ori.y,ori.z])
        forward_vector = [math.cos(rot[2]), math.sin(rot[2])]
        # print(f"Forward vector: {forward_vector}")

        # Create a twist to hold movement info
        move_twist = Twist()
        move_twist.linear.x = 0
        move_twist.linear.y = 0
        move_twist.linear.z = 0
        move_twist.angular.x = 0
        move_twist.angular.y = 0
        move_twist.angular.z = 0

        # Angular velocity
        if action[0] == "R": # Right Turn
            # Short straight move
            move_twist.angular.z = math.radians(-17.5)
        elif action[0] == "L": # Left Turn
            # Long straight move
            move_twist.angular.z = math.radians(17.5)

        # Linear velocity
        if action[1] == "S":
            # Short straight move
            move_twist.linear.x = forward_vector[0] * 0.03
            move_twist.linear.y = forward_vector[1] * 0.03
        elif action[1] == "L":
            # Long straight move
            move_twist.linear.x = forward_vector[0] * 0.06
            move_twist.linear.y = forward_vector[1] * 0.06
        
        # Publish the given twist
        # rospy.loginfo(f"Publishing move_twist: {move_twist}")
        self.movement_pub.publish(move_twist)

    def get_next_action(self)->int:
        """
        Uses the epsilon-greedy algorithm to choose the next action to take.
        Returns
        -------
        int : The index of the next action to take.
        """
        # If random normalized value is less than epsilon
        if np.random.random() < self.epsilon:
            # Choose the most promising value from the q-table for this state
            # rospy.loginfo(f"CS: {self.current_state[0]}, {self.current_state[1]}, {self.current_state[2]}, {self.current_state[3]}")
            return np.argmax(self.q_table[self.current_state[0], self.current_state[1], self.current_state[2], self.current_state[3]])
        else: # Otherwise, select a random action
            return np.random.randint(len(self.actions)) # Random value 0 to len(self.actions)-1
            

    #endregion

    #region Gazebo Services

    def init_gazebo(self)->None:
        # Create Gazebo proxy functions
        self.gz_reset_proxy = rospy.ServiceProxy('/gazebo/reset_simulation', Empty)
        self.gz_get_model_proxy = rospy.ServiceProxy('/gazebo/get_model_state', GetModelState)
        self.gz_set_model_proxy = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
        self.gz_unpause_phys_proxy = rospy.ServiceProxy('/gazebo/unpause_physics', Empty)
        self.gz_pause_phys_proxy = rospy.ServiceProxy('/gazebo/pause_physics', Empty)

    def gz_reset_simulation(self)->bool:
        """ Reset the Gazebo simulation. """
        rospy.loginfo("Waiting for service: /gazebo/reset_simulation...")
        rospy.wait_for_service('/gazebo/reset_simulation')
        try:
            self.gz_reset_proxy()
            rospy.loginfo("Gazebo simulation reset complete!")
            return True
        except (rospy.ServiceException) as exc:
            rospy.logerr(f"/gazebo/reset_simulation service call failed.\nError: {str(exc)}")
            return False

    def gz_get_model_state(self)->tuple:
        """
        Get and return the state of the robot model in Gazebo.
        
        Returns
        -------
        tuple : An (x_pos, y_pos, z_rot) tuple with position information from the model state.
        """
        # rospy.loginfo("Waiting for service: /gazebo/get_model_state...")
        rospy.wait_for_service('/gazebo/get_model_state')
        try:
            response = self.gz_get_model_proxy("turtlebot3_waffle_pi", "") #TODO: Is this set of strings correct?
            # rospy.loginfo(f"Got Gazebo model state!")
            return (response.pose.position, response.pose.orientation)
        except (rospy.ServiceException) as exc:
            rospy.logerr(f"/gazebo/get_model_state service call failed.\nError: {str(exc)}")
            return None

    def gz_set_model_state(self, x_pos:float = 0.0, y_pos:float = 0.0, z_rot: float = 0.0)->bool:
        """ Set the state of the robot model in Gazebo. """
        rospy.loginfo("Waiting for service: /gazebo/set_model_state...")
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            # Convert Euler rotation to quaternion
            rot_quat = quaternion_from_euler(0.0, 0.0, math.radians(z_rot))

            new_model_state = ModelState()
            new_model_state.model_name = "turtlebot3_waffle_pi"
            new_model_state.pose.position.x = x_pos
            new_model_state.pose.position.y = y_pos
            new_model_state.pose.position.z = 0
            new_model_state.pose.orientation.x = rot_quat[0]
            new_model_state.pose.orientation.y = rot_quat[1]
            new_model_state.pose.orientation.z = rot_quat[2]
            new_model_state.pose.orientation.w = rot_quat[3]

            self.gz_set_model_proxy(new_model_state)
            # rospy.Rate(1).sleep() # Sleep for 1 second to ensure proper reset
            rospy.loginfo("Set Gazebo model state!")
            return True
        except (rospy.ServiceException) as exc:
            rospy.logerr(f"/gazebo/set_model_state service call failed.\nError: {str(exc)}")
            return False

    def gz_unpause_physics(self)->bool:
        """ Unpause the Gazebo physics. """
        rospy.loginfo("Waiting for service: /gazebo/unpause_physics...")
        rospy.wait_for_service('/gazebo/unpause_physics')
        try:
            self.gz_unpause_phys_proxy()
            rospy.loginfo("Gazebo physics unpaused!")
            return True
        except (rospy.ServiceException) as exc:
            rospy.logerr(f"/gazebo/unpause_physics service call failed.\nError: {str(exc)}")
            return False

    def gz_pause_physics(self)->bool:
        """ Pause the Gazebo physics. """
        rospy.loginfo("Waiting for service: /gazebo/pause_physics...")
        rospy.wait_for_service('/gazebo/pause_physics')
        try:
            self.gz_pause_phys_proxy()
            rospy.loginfo("Gazebo physics paused!")
            return True
        except (rospy.ServiceException) as exc:
            rospy.logerr(f"/gazebo/pause_physics service call failed.\nError: {str(exc)}")
            return False

    #endregion

if __name__ == '__main__':
    # Initialize our Wallfollow Agent
    wallfollow_agent = WallfollowAgent()