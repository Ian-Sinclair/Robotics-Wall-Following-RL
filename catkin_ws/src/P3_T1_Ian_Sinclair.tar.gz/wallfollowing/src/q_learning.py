#!/usr/bin/env python3
import itertools
import json
import math
import sys
import rospy
import numpy as np
import os
import random

from std_srvs.srv import Empty
from gazebo_msgs.msg import ModelState 
from gazebo_msgs.srv import SetModelState
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

'''
    Here a state is defined by the triple,
    state = ( right_ status , front_status , left_status )

    Where each status can be anything in the form of,
        right_status  <-- ['to close' , 'good' , 'medium' , 'far']
        front_status  <-- ['to close' , 'good' , 'medium' , 'far']
        left_status  <-- ['to close' , 'good' , 'far']

        And so there are 4*4*3 = 48 total states
    
    The status of each direction is informed by the minimum distance
    along a range of lidar scans
    In ccw degrees where 0 degrees is directly in front of the robot, the scan ranges
    are taken as follows

        right  <-- (210 , 330) degrees
        front <-- (-14 , 14) degrees
        left <-- (30 , 150) degrees
    
    The minimum distance of each is discretized to inform the status

    This is done using custom thresholds for each direction.
    'right' : {'to close' : (0 , 0.5*d_w) , 'good' : (0.5*d_w , 1.2*d_w) , 'medium' : (1.2*d_w , 1.5*d_w), 'far' : (1.5*d_w , 4)},
    'front' : {'to close' : (0 , 1.2*d_w) , 'good' : (1.2*d_w , 1.3*d_w) , 'medium' : (1.3*d_w , 3*d_w), 'far' : (3*d_w , 4)},
    'left' : {'to close' : (0 , 0.7*d_w) , 'good' : (0.7*d_w , 2.5*d_w) , 'far' : ( 2.5*d_w , 4)},

    Where d_w is the desired distance from the wall.
    Typically d_w = 0.75

    Lastly possible actions from each state include

    actions = ['straight' , 'slight left' , 'slight right' , 'hard right' , 'hard left']

    which are used to inform the new velocity of the robot.

'''



class q_learning() :
    def __init__( self , filename = None) :
        self.cache = {'scan data' : None ,
                 'state' : None ,
                 'velocity' : None ,
                 'incoming scan data' : None}
        
        #  Sensor ranges in degrees for which lidar sensors to use for each direction
        #  on the robot.
        self.scan_key = {
            'right' :  [ (210,330) ],
            'front' : [ (0,14) , (345,359) ] ,
            'left' : [ (30,150) ]
        }

        #  List of all possible actions from any state.
        self.actions = ['straight' , 'slight left' , 'slight right' , 'hard right' , 'hard left']

        #  Velocity map for each action.
        self.actions_velocities = {'straight' : ( 0.35 , 0 ) , 
                                    'slight left' : ( 0.35 , math.pi/8 ) , 
                                    'slight right' : ( 0.35 , -math.pi/8 ) , 
                                    'hard right' : ( 0.2 , -math.pi/4 ) , 
                                    'hard left' : ( 0.2 , math.pi/4 )
                                    }

        '''
            A single state is defined by the status of 
            each element in the tuple (right , front , left)
        '''
        self.directional_states = {
            'right' : ['to close' , 'good' , 'medium', 'far'],
            'front' : ['to close' , 'good' , 'medium', 'far'],
            'left' : ['to close' , 'good' , 'far'],
        }

        #  Desired distance from walls
        d_w = 0.75

        #  Sets state thresholds to discretized scan distance data.
        self.thresholds = {
            'right' : {'to close' : (0 , 0.5*d_w) , 'good' : (0.5*d_w , 1.2*d_w) , 'medium' : (1.2*d_w , 1.5*d_w), 'far' : (1.5*d_w , 4)},
            'front' : {'to close' : (0 , 1.2*d_w) , 'good' : (1.2*d_w , 1.3*d_w) , 'medium' : (1.3*d_w , 3*d_w), 'far' : (3*d_w , 4)},
            'left' : {'to close' : (0 , 0.7*d_w) , 'good' : (0.7*d_w , 2.5*d_w) , 'far' : ( 2.5*d_w , 4)},
        }


        #  Creates a blank Q table with all state/action pairs. And saves to file.
        if filename == None :
            self.q_table = {}


            '''
                Detect walls on the right.
                    Right side --> all base states
                    front --> all base states
                    left --> to close , good , far
                    behind --> none
            '''

            new_states = []
            for direction,states in self.directional_states.items() :
                mod_states = []
                for s in states :
                    mod_states += [ direction + ' : ' + s ]
                new_states += [ mod_states ]

            new_states = [s for s in itertools.product(*new_states)]

            self.q_table = self.construct_blank_q_table( {} , new_states , self.actions , default_value=0 )

            self.save_q_table_to_JSON( self.q_table , 'Manual_Q_table' )
        
        #  Loads Q table from file
        if type(filename) == type(' ') :
            self.q_table = self.load_q_table_from_JSON( filename )

        self.init_node()
        self.init_subscriber()
        self.init_publisher()
        self.init_services()

        #  Runs demo of q_table.
        self.demo( self.q_table )

    def init_node( self ) :
        rospy.init_node( 'wall_following' , anonymous=True )


    def init_publisher( self ) :
        '''
            Inits publisher to cmd_vel with message Twist.
            (Controls the velocity of the robot)
        '''
        self.velocity_publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

    def init_subscriber(self) :
        '''
            Subscribes to /scan topic into self.scan_callback function
            and to /cmd_vel into self.cmd_vel_callback function.
        '''
        rospy.Subscriber('scan' , LaserScan , callback=self.scan_callback)
        rospy.Subscriber("/cmd_vel", Twist, callback=self.cmd_vel_callback)


    def init_services( self ) :
        '''
            Loads ROSPY services for interfacing with Gazebo simulation
        '''

        rospy.loginfo(f'-----Waiting For Services-----')
        rospy.wait_for_service('/gazebo/reset_world')
        try :
            self.reset_world = rospy.ServiceProxy('/gazebo/reset_world', Empty)
            rospy.loginfo(f'-----Rospy Service [reset world] activated')
        except :
            rospy.logerr(f'Unable to connect to rospy service reset world')
            raise
            
        rospy.wait_for_service('/gazebo/set_model_state')
        try:
            self.set_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
            rospy.loginfo(f'-----Rospy Service [set model state] activated')
        except :
            rospy.logerr(f'Unable to connect to rospy service set model state')        




    def scan_callback( self , scan ) :
        '''
            Sets scan data cache when new scan information is available.
        '''
        '''
            Possibly encode state, then check if state has been updated?
            http://docs.ros.org/en/noetic/api/sensor_msgs/html/msg/LaserScan.html
        '''
        self.cache['scan data'] = scan
        self.cache['incoming scan data'] = scan

    def cmd_vel_callback( self , data ) :
        '''
            Maintains a record of the current velocity of the robot
        '''
        self.cache['velocity'] = data



    def num_to_threshold( self , direction , value ) :
        '''
            Converts distance value in a direction into a discrete threshold
            Thresholds are initialized in __init__() and are static.
        '''
        for key,threshold in self.thresholds[direction].items() :
            a,b = threshold
            if a <= value < b :
                return key


    def scan_to_state( self , scanArray ) :
        '''
            Discretizes scan information into Q table states.
        '''
        scanArray = list(np.clip(scanArray , a_min=0 , a_max=3.5))
        state = []
        for direction,ranges in self.scan_key.items() :
            state_range = []
            for a,b in ranges :
                state_range += scanArray[a:b]
            value = min(state_range)
            threshold = self.num_to_threshold( direction , value )
            state += [f'{direction} : {threshold}']
        return tuple(state)


    def publish_velocity( self, x = 0 , y = 0 , z = 0 , nx = 0 , ny = 0 , nz = 0 ) :
        '''
            Converts velocity information to Twist object
        '''
        twist = Twist()
        twist.linear.x = x
        twist.linear.y = y
        twist.linear.z = z
        twist.angular.x = nx
        twist.angular.y = ny
        twist.angular.z = nz
        self.velocity_publisher.publish( twist )


    def get_state_from_sub_scan( self , sub_scan , states ) :
        '''
            Convert states into actual ranges
            check which state the minimum of range belongs to
            return that state.
        '''
        pass


    def save_q_table_to_JSON( self , q_table , filename) :
        """Saves Q Table dictionary as JSON file at 'filename' location

        Args:
            q_table (dict): Q table to be saved
            filename (str): unextended filename

        Returns:
            Boolean: Returns False if failed, otherwise True.
        """        
        #  Filenames for important documents are protected so they cant be written over
        if filename in ['Manual_Q_table'] :
            rospy.logerr(f'filename: {filename} is protect, save Q table to a different filename')
            return False
        
        #  Converts tuple type state keys to string type
        string_q_table = {}
        for key in q_table.keys() :
            str_key = ''
            for s in key :
                str_key += s + '\t'
            string_q_table[str_key] = q_table[key]
            
        #  Dumps to JSON
        with open(f"{filename}.json" , "w" ) as f:
            json.dump( string_q_table , f , indent=4 )
        return True


    def load_q_table_from_JSON( self , filename ) :
        """Loads q_table from JSON file at filename.
            EX: load_q_table_from_JSON( 'Manual_Q_table' )
            NOTE: File must be in same location as python script.
                /catkin_ws/src/wallfollowing/src/...

        Args:
            filename (str): unextended filename

        Returns:
            dict: Q table
        """        
        q_table = {}
        with open(os.path.join(sys.path[0], f'{filename}.json'), "r") as json_file:
            data = json.load(json_file)
        for string,actions in data.items() :
            key = tuple( string.split('\t')[:-1] )
            q_table[key] = actions
        
        return q_table


    def set_model_pos(self,x=0,y=0,z=0,nx=0,ny=0,nz=0,w=1) :
        """Sets the position of the waffle bot in the world

        Args:
            x (int, optional): position in x. Defaults to 0.
            y (int, optional): position in y. Defaults to 0.
            z (int, optional): position in z. Defaults to 0.
            nx (int, optional): Rotation in x quaternion. Defaults to 0.
            ny (int, optional): Rotation in y quaternion. Defaults to 0.
            nz (int, optional): Rotation in z quaternion. Defaults to 0.
            w (int, optional): Rotation in w quaternion. Defaults to 1.
        """        
        state_msg = ModelState()
        state_msg.model_name = 'turtlebot3_waffle'
        state_msg.pose.position.x = x
        state_msg.pose.position.y = y
        state_msg.pose.position.z = z
        state_msg.pose.orientation.x = nx
        state_msg.pose.orientation.y = ny
        state_msg.pose.orientation.z = nz
        state_msg.pose.orientation.w = w

        try :
            self.set_state( state_msg )
        except :
            raise

    def run_epoc( self ) :
        '''
            runs a single epoc in training
        '''
        pass
    

    def demo( self , q_table = None , limit = 25) :
        """Demo a q_table strategy in gazebo
            After the robot hits a wall, the simulation will
            reset, and the robot will be randomly placed on the map.
            by default there are100 maximum simulation resets, 
            until the demo completes.

        Args:
            q_table (dict, optional): Q table to demo if None then demos class q_table. Defaults to None.
            limit (int , optional): maximum number of times the simulation can reset.
        """        

        #  Wait for gazebo's first callback
        while self.cache['scan data'] == None and not rospy.is_shutdown() :
            rospy.loginfo(f'-----Waiting for scan data-------')
            rospy.sleep(1)

        if q_table == None :
            q_table = self.q_table

        rospy.loginfo('Demo: initialized')
        count = 0
        while not rospy.is_shutdown() and count < limit :
            rospy.sleep(0)

            #  Discretized scan data to Q table state information
            state = self.scan_to_state(self.cache['scan data'].ranges)
            self.cache['state'] = state

            #  Gets the highest utility action for the robots current state
            action = max( q_table[state], key = q_table[state].get )

            #  Converts Q table action to linear and angular velocities
            x , nz = self.actions_velocities[action]

            #  Publishes linear and angular velocities as Twist object 
            self.publish_velocity( x = x , nz = nz )


            #  Resets simulation if robot is blocked
            if self.is_blocked(self.cache['scan data'].ranges) :
                rospy.loginfo(f'----Resetting World-----')
                self.reset_world()
                self.set_model_pos(
                    x = 4*random.random() - 2 ,
                    y = 4*random.random() - 2 ,
                    nz = 4*random.random() - 2
                )
                #  Waits for new lidar data after resetting the robot.
                self.cache['incoming scan data'] = None
                while self.cache['incoming scan data'] == None and not rospy.is_shutdown() :
                    rospy.loginfo(f'-----Waiting for scan data-------')
                    rospy.sleep(1)
                count += 1
                rospy.loginfo(f'Wallfollowing Attempt {count}/{limit}')
                continue
        rospy.loginfo(f'-------DEMO Complete--------')

            
            



    def is_blocked( self, scanArray) :
        '''
            NOTE! either check every lidar scanner or just the front. (right now checking everything.)
        '''
        for range in scanArray :
            if range < 0.2 :
                return True
        return False

    def construct_blank_q_table( self , q_table : dict, states : list , actions : list, default_value = 0 ) :
        action_dict = {}
        for a in actions :
            action_dict[a] = 0
        for state in states :
            q_table[state] = action_dict
        return q_table



if __name__ == '__main__':
    q_learning(filename='Manual_Q_table')